<?php 
	//输出变量值的方式
	//1.echo :输出一个或多个字符串，(常用的)
	// 多个用，进行隔开
	//2.print：输出一个字符串
	//3.printf:输出格式化字符串，
	// ％d 整数, %f浮点型(默认小数点6位数) %s字符串
	//4.var_dump(),类型，数值都会输出，常用于调试
	//5.print_r:输出数组
	
	//PHP数据类型8种（标量数据类型）
	$name = "www";//字符串
	$isMan = false;//布尔
	$age = 18;//整型
	$height = 1.58;//浮点型
	
	echo $name,$isMan;
	echo "<hr/>";
	//布尔值为false时不输出，true输出1
	printf("%010d,aaaa%.1f,%s",$age,$height,$name);
	echo "<hr/>";
	var_dump($isMan,$name);
	echo "<hr/>";
	//变量的赋值（直接赋值(传值)，引用赋值（传址）
//	$a = 10;
//	$b = $a;
//	$a = 5;
//	echo $b;//10
	
	$a = 10;
	$b = &$a;
	$a = 5;
	echo $b;//5
	echo "<hr/>";
	
	//变量的变量(表单提交)
	
	$hello = "b23";
	$$hello = "456";
	//$b23 = "456";
	echo $b23;
	echo "<hr/>";
	
	//索引数组（以索引下标进行的对应）
	//  0  111
	//  a  111
	$aa = array('111','222','333');
	print_r($aa);
	
	echo "<hr/>";
	//关联数组($key  -- value)
	$bb = array('bbb'=>'111','b'=>'222');
	print_r($bb['bbb']);
	echo "<hr/>";
	
	//字符串的注意点
	//1.单引号和双引号（只有双引号里面的变量才能被识别）
	//2.可以通过{}进行变量包裹确保识别的正确性
	//3.定界符：(html混编时可能需要用到)
	//结束标识符所在行不允许有其他字符，要顶行写
	$name = "xiaohuaasdasdasdas
	asdsdasdasdasd
	dasdadasdasdas
	dasdasdasd";
	
	$name = <<<AAA
	<html>
	    <p></p>
	</html>
	
AAA;
    
	echo "hsdsdsdksdmd{$name}snsdjjdj";
	
	
 
	
	
	
	
	
?>