<?php 
	
	//常量(常量名大写,常量值，是否对大小写敏感，默认false)
	//
	//定义
	define('PI', '3.1415926'+ 5);
	echo PI*2;//  16.
	echo "<hr/>";
	//
	$aa = 123.0;
//	echo gettype($aa);
	//类型：gettype进行获取
	//is_type()  false true
	//          不显示   1
	echo is_double($aa);
	
	
?>
	