<?php 
	//如果是get方式提交的数据接收时  $_GET
	//如果是post方式提交的数据接收时  $_POST
 
// 	var_dump($_GET);
	var_dump($_POST);
	echo '<hr/>';
//	array(2) 
//	{ ["name"]=> "eeee" [" "]=> "12345" }

//	$name = $_POST['name'];  
//	$pass = $_POST['aa'];

	
	//字符串连接通过.进行连接
//	echo $name;
//	echo '<hr/>';
//	echo $pass;
//	echo $name.'<hr/>'.$pass;
	//对数组进行遍历，并一一对应
	foreach ($_POST as $key => $value) {
//		echo $key."+".$value;
//		name+www
//		$key = name;
//		$value = www;
//		$$key = $name = www = $value;
//		pass+123
//		$key = pass;
//		$$key = $pass = 123 = $value;
//		$value = 123;
		$$key = $value;
		//通过遍历，不需要一一进行获取，
        //可直接通过表单页面传递过来的name值直接进行$name数据处理
		
	}
	//输出值(输入框里面的内容)
	echo $name."<hr>".$pass."<hr>"; 
	
	//name ,pass
	







//	$name = $_POST['names'];
//	echo $name;
//	var_dump($_POST);
//	echo '<hr/>';
//	$name =$_POST['names'];
//	echo $name;
//	array(2) { ["names"]=> string(9) "王文文" ["gender"]=> string(3) "111" }
//	$_POST array ["names"=>"lck","gender"=>"man"]
//	foreach类似于forin
//	foreach ($_POST as $key => $value) {
//		//通过变量的变量进行赋值
//		$$key = $value;
////		$names = "www";
////		$gender = "man";
//	}
//	echo $names."<hr>".$gender."<hr>"; 
?>