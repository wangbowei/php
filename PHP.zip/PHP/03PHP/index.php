<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Document</title>
	<!--php可以实现与html的混编，可以多个-->
</head>
<body>
	<p>你 hi 大家记<?php 
		echo "aaa";
		?>得你的啊 </p>
		<?php echo "<hr/>"?>
</body>
</html>