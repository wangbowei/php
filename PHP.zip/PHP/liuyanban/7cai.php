<?php
	//cai--1,ding--0   cai--0,ding--1   //cai--0,ding--0 
 
	//点击ding操作
	//查看用户是否对该留言进行过操作
		//如果进行过操作，
		//先查看是否之前对该留言进行过cai操作，
		//如果有查看到cai操作，用户就取消cai操作，进行ding操作  cai--0,ding--1
		//如果没有进行cai操作，用户是否进行过ding操作，如果没有,进行ding操作
		//                                          如果有,进行取消ding操作
	 
	 //如果查不到该数据
	//就进行ding操作，
	//往userwork表中插入记录数据（ding--1,cai--0）
	
	
	 
	
	//1.连接数据库
	include_once "common.php";
	//2.获取关于留言的ID标识
	$liuyanId = $_GET["liuyanID"];
	//3.获取现在登录的用户的ID标识
	session_start();
	$userId = $_SESSION["id"];
	
	$sql = "SELECT * FROM userwork WHERE userid=$userId AND liuyanid = $liuyanId";
	$result = $mysqli->query($sql);
	if($result->num_rows){
		$row = $result->fetch_assoc();
		//看一下是否进行踩操作
		$ding = $row["ding"];
		$workId = $row["work_id"];
		if($ding == 0){//没有进行过踩操作，可以对顶进行操作
			$cai= $row["cai"];
			//查看用户之前对顶进行了什么操作
			if($cai == 0){
				$cai = 1;
			}else{
				$cai = 0;
			}
			//更新用户操作表
			$sql = "UPDATE userwork SET cai = $cai WHERE work_id = $workId";
			$result = $mysqli->query($sql);
			if($result){
				$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND cai = 1";
				$result = $mysqli->query($sql);
				if($result->num_rows){
					$row = $result->fetch_assoc();
					$count_cai = $row["count(work_id)"];
				}
			 }
		}else{
			//进行过踩操作,取消踩操作，进行顶操作
			$cai = 1;
			$ding = 0;
			//更新用户操作表
			$sql = "UPDATE userwork SET ding = 0,cai = 1 WHERE work_id = $workId";
			$result = $mysqli->query($sql);
			if($result){
				$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND cai = 1";
				$result = $mysqli->query($sql);
				if($result->num_rows){
					$row = $result->fetch_assoc();
					$count_cai = $row["count(work_id)"];
					
				}
				
		   }
			
		}
		$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND ding = 1";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			$row = $result->fetch_assoc();
			$count_ding = $row["count(work_id)"];
			
		}
	}else{
		//向表中插入该记录
		$cai = 1;
		$ding = 0;
		
		$sql = "INSERT INTO userwork(userid,liuyanid,ding,cai) VALUES($userId,$liuyanId,0,1)";
		$result = $mysqli->query($sql);
		if($result){
			//查看数据表中有关该留言的被顶的总数
			$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND cai = 1";
			$result = $mysqli->query($sql);
			if($result->num_rows){
				$row = $result->fetch_assoc();
				$count_cai = $row["count(work_id)"];
			}
			
		}
		$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND ding = 1";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			$row = $result->fetch_assoc();
			$count_ding = $row["count(work_id)"];
			
		}
	}
	//更新留言信息表中的数据
	$sql = "UPDATE liuyaninfo SET ding = $count_ding,cai=$count_cai  WHERE liuyan_id = $liuyanId";
	$result = $mysqli->query($sql);
	if($result){
  		echo '{"count_ding":"'.$count_ding.'","ding":"'.$ding.'","cai":"'.$cai.'","count_cai":"'.$count_cai.'"}';
	}

?>