<?php
	var_dump($_POST);
	//1.连接数据库
	include_once "common.php";
	//2.获取登录的用户信息
	//3.在数据表userinfo查看是否有该用户，
	//如果有进行跳转到留言板界面
	
	if(isset($_POST["name"])){
		$name = $_POST["name"];
	}
	if(isset($_POST["password"])){
		$pass = $_POST["password"];
	}
		//设置cookie的过期时间
		//默认关闭浏览器时过期
		//参数名，内容，过期时间
	//如果获取到POST中cookie，代表了点击了记住我
	if(isset($_POST["cookie"])){
	    setcookie("name",$name,time()+3600*24*7);
		setcookie("pass",$pass,time()+3600*24*7);
	}
	$sql = "SELECT * FROM userinfo WHERE name='$name' AND pass='$pass'";
	$result = $mysqli->query($sql);
	if($result->num_rows){
		$row = $result->fetch_assoc();
		//将该记录的id进行存储，方便知道到底是哪个用户
		session_start();
		$_SESSION["id"]=$row["id"];
		//登录成功进行跳转到留言界面
		header("Location:03list.php");
	}else{
		alert("用户名或密码错误");
	}
 	
 	
 	

?>