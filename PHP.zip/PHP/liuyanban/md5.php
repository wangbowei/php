<?php
	//md5加密
	echo "wangww";
	echo "<hr/>";
	echo md5("wangww");

?>