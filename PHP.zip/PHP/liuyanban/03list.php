<?php
	//踩和顶(cai.php/ding.php)
	//jquery手册，next(),prev() 
	//data:(count_ding,count_cai,ding,cai)
	//（数据成功接收到，根据拿到的数据做相应的dom操作）
	
	//1.页面页数的优化（dom耗性能）
	//判断一下返回当前的页面的总个数pages，和当前的页数做个比较
	//如果大于，追加一个a标签
	//如果小于，删除最后一个a标签
	 
	//2.删除按钮的优化
	//显示时做一个判断，看liuyaninfo发布人userid是否与当前登录用户的id一致，
	//????
	//删除li时，第二页的第一条记录拿过来，？判断是否该有删除按钮
	//方法1 ：给删除按钮设置样式，display＝“none”；
	//只有登录的userid与该数据一致时才显示display＝“block”；
	//方法2：先不写，判断之后在进行往里面进行追加删除按钮
	//方法3：放一个空字符串
	
	 
	
	
	
	 include_once "common.php";
	 session_start();
	 $userid = $_SESSION["id"];
	 echo $userid;
	
	  
	 $sql = "SELECT count(liuyan_id) FROM liuyaninfo WHERE deleteId = 0";
	 $result = $mysqli->query($sql);
	 $row = $result->fetch_assoc();
	 $count = $row['count(liuyan_id)'];
	 $pages = ceil($count / PAGESIZE); 
	 //当前是显示的第几页
	 $page = 0;
	 if(isset($_GET["page"])){
	 	$page = $_GET["page"];
	 }
	 $index = $page * PAGESIZE;
	 $sql = "SELECT *  FROM liuyaninfo where deleteId  = 0 ORDER BY times DESC,liuyan_id DESC limit $index,".PAGESIZE;
	 $result = $mysqli->query($sql); 

?>
<!DOCTYPE html>
<html>
	<head>
		<title>留言板信息展示界面</title>
		<meta charset="UTF-8"/>
		<style type="text/css">
			body,html{
				margin: 0;
				padding: 0;
				background: #eee;
				text-align: center;
			}
			#bodys{
				margin: auto;
				text-align: left;
				padding: 20px 10px;
				width: 355px;
				/*height: 600px;*/
				border: 1px solid #aaa;
			}
			#content{
				width: 300px;
				height: 150px;
			}
			button{
				display: block;
				width: 90px;
				height: 30px;
				background: white;
			}
			#center{
				display: table;
			}
			#ccc{
				display: table-cell;
				vertical-align: middle;
			}
			ul{
				list-style-type: none;
				padding: 0;
				margin: 10px 0 0px;
				
			}
			li{
				text-indent: 30px;
				background: white;
				list-style: none;
				margin: 0;
				padding: 0;
				overflow: hidden;
				padding-right: 10px;
				border-bottom: 1px solid #ccc;
			}
			.right{
				text-align: left;
			}
			 
		</style>
	</head>
	<body>
		<input type="hidden" name="ids" id="ids" value="" />
		<div id="bodys">
			<div id="center">
				<span id="ccc">内容：</span>
				<textarea id="content" name="" rows="" cols=""></textarea>
				<button id="sub" onclick="sub()">提交</button>
			</div>
		    <div >
				<input type="hidden" name="page" id="page" value="<?php echo $page; ?>" />
			</div>
			<ul id="uls">
				<?php 
					if ($result->num_rows) {
						while ($row = $result->fetch_assoc()) {
				?>
					<li class="parents">
						<p><?php echo $row["context"]; ?></p>
						<p>
							<p class='right'>
								<span><?php echo date("Y年m月d日 H:i ",$row["times"]); ?></span>
								顶：<a href='#' data_id="<?php echo $row["liuyan_id"];?>" onclick="ding(this)"><?php  echo $row["ding"];?></a>
								踩：<a href='#' data_id="<?php echo $row["liuyan_id"];?>" onclick="cai(this)"><?php  echo $row["cai"];?></a>
							    <?php 
							    	if($row["userid"]==$userid){
							    	?>
							    	<a href="#" data_id="<?php echo $row["liuyan_id"];?>" onclick="del(this)">删除</a>
							    	
							    	<?php	
							    	}
							     ?>
								   
								
							</p>
						</p>
					</li>
				<?php
						}
					}  	
				?>
			 </ul>
		     <div id="pages">
		     	<?php 
				    for($i = 1; $i <= $pages; $i++){
				    		$count = $i-1;
				     	echo "<a href='03list.php?page=$count'>$i</a>&nbsp";
				     } 
				?>
			</div>
		</div>
	 </body>
</html>
<script src="jquery-1.12.2.min.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
	
	 
	//点击提交按钮
	function sub(){
		var content = $("#content").val();
		$.ajax({
			type:"get",
			url:"04add.php",
			async:true,
			data:{
				context:content
			},
			dataType:"json",
			success:main,
			error:errors,
		})
	}
	function main(data){
		
//	   console.log(data);
	   var liObj = $('<li class="parents">'+
					'<p>'+data.context+'</p>'+
					'<p>'+
						'<p class="right">'+
							'<span>'+data.timeStyle+'</span>'+
							'顶：<a href="#" data_id="'+data.liuyan_id+'" onclick="ding(this)">'+data.ding+'</a>'+
							'踩：<a href="#" data_id="'+data.liuyan_id+'" onclick="cai(this)">'+data.cai+'</a>'+
							'<a href="#" data_id="'+data.liuyan_id+'"  onclick="del(this)">删除</a>'+
						'</p>'+
					'</p>'+
				'</li>');
		$("#uls").prepend(liObj);
		var h = liObj.height();
		liObj.animate({
			height:h
		});
		if ($("li").length == 6) {
			$("li:last-child").animate({
				height:0
			},function(){
				$("li:last-child").remove();
			});
		}
		//获取此时页面中的a链接的个数
	    var a_count = $("#pages a").length;
		if(data.pages > a_count){
			//进行追加a
			$("#pages").append("<a href='03list.php?page="+a_count+"'>"+data.pages+"</a>&nbsp");
		}
		 
//	    //让页面中的页数进行清空，重新for循环
//		$("#pages").html("");
//		for (var i=1;i<=data.pages;i++) {
//			var j=i-1;
//			$("#pages").append("<a href='03list.php?page="+j+"'>"+i+"</a>&nbsp");
//		}
		 
	}
	function errors(data){
		console.log("失败");
		console.log(data);
	}
	//删除
	//onclick="del(this)，this代表当前这个标签节点， this就代表li这个节点。
	function del(obj){
		//当前的页面数
		 var page = $("#page").val();
		//获取需要删除的该留言标识
		var id = $(obj).attr("data_id");
		$.ajax({
	        	type:"get",
	        	url:"05delete.php",
	        	async:true,
	        	data:{
	        		id:id,
	        		page:page,
	        	},
	        	dataType:"json",
	        	success:function(data){
	        		console.log(data);
	        		//将该点击的li进行删除，高度变为0，移除该li
	        	    //将拿到的下一页的数据插入到ul中最后一个
	        	    //如何拿到点击的li呢？？？
	        	    //查找该对象的所有li的父元素
	        	    //parents() 获得当前匹配元素集合中每个元素的祖先元素
	        		var lis = $(obj).parents("li");
				lis.animate({
					height:0
				},function(){
					lis.remove();
				});
				
				var str ='';
				var userID = <?php echo $userid;?>;
				if(data.userid == userID){
					str=	'<a href="#" data_id="'+data.liuyan_id+'"  onclick="del(this)">删除</a>';

				}
//			 
			 
				var liObj = $('<li class="parents">'+
								'<p>'+data.context+'</p>'+
								'<p>'+
									'<p class="right">'+
										'<span>'+data.timeStyle+'</span>'+
										'顶：<a href="#" data_id="'+data.liuyan_id+'" onclick="ding(this)">'+data.ding+'</a>'+
										'踩：<a href="#" data_id="'+data.liuyan_id+'" onclick="cai(this)">'+data.cai+'</a>'+
										 str+
									'</p>'+
								'</p>'+
							'</li>');
				//data.userid ----- 
				
				 if(!data.msg){
					liObj.appendTo($("#uls"));
					var h = liObj.height();
					liObj.height(0);
					liObj.animate({
						height:h
					});
				}
				//获取此时页面中的a链接的个数
	    			var a_count = $("#pages a").length;
				if (data.pages < a_count) {
					//删除最后一个a标签
					$("#pages a:last-child").remove();
				}
				 
//				//让页面中的页数进行清空，重新for循环
//				$("#pages").html("");
//				for (var i=1;i<=data.pages;i++) {
//					var j=i-1;
//					$("#pages").append("<a href='03list.php?page="+j+"'>"+i+"</a>&nbsp");
//				}
			 },
			 error:function(data){
			 	 console.log(data);
			 }
        });
     }
     //点击顶操作
     function ding(obj){
     	//对哪条留言进行顶操作，留言的ID标识
     	var liuyanid = $(obj).attr("data_id");
     	 $.ajax({
     	 	type:"get",
     	 	url:"006ding.php",
     	 	async:true,
     	 	data:{
     	 		liuyanID:liuyanid,
     	 	},
     	 	dataType:"json",
     	 	success:function(data){
     	 		console.log(data);
     	 		$(obj).html(data.count_ding);
     	 		//(ding--0,cai--1)
     	 		$(obj).next().html(data.count_cai);
     	 		if(data.ding == 1){
     	 			$(obj).css("color","red");
     	 		}else{
     	 			$(obj).css("color","black");
     	 		}
     	 		if(data.cai == 1){
     	 			$(obj).next().css("color","red");
     	 		}else{
     	 			$(obj).next().css("color","black");
     	 		} 
     	 	},
     	 	error:function(data){
     	 		console.log(data);
     	 	}
     	 });
       }
       function cai(obj){
       		//对哪条留言进行cai操作，留言的ID标识
	     	var liuyanid = $(obj).attr("data_id");
	     	 $.ajax({
	     	 	type:"get",
	     	 	url:"7cai.php",
	     	 	async:true,
	     	 	data:{
	     	 		liuyanID:liuyanid,
	     	 	},
	     	 	dataType:"json",
	     	 	success:function(data){
	     	 		console.log(data);
	     	 		$(obj).html(data.count_cai);
	     	 		//更新顶的数据
	     	 		$(obj).prev().html(data.count_ding);
	     	 		if(data.cai==1){
	     	 			$(obj).css("color","red");		
	     	 		}else{
	     	 			$(obj).css("color","black");
	     	 		}
	     	 		if(data.ding==1){
	     	 			$(obj).prev().css("color","red");		
	     	 		}else{
	     	 			$(obj).prev().css("color","black");
	     	 		} 
	     	 	
	 
	     	 	},
	     	 	error:function(data){
	     	 		console.log(data);
	     	 	}
	     	 });
       }
     
</script>