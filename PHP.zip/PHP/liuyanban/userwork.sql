-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2016-10-14 12:06:58
-- 服务器版本： 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `liuyanban`
--

-- --------------------------------------------------------

--
-- 表的结构 `userwork`
--

CREATE TABLE `userwork` (
  `work_id` int(10) NOT NULL COMMENT '操作ID标识',
  `userid` int(10) NOT NULL COMMENT '用户的ID',
  `liuyanid` int(10) NOT NULL COMMENT '留言的ID',
  `cai` int(10) NOT NULL DEFAULT '0' COMMENT '对踩的操作',
  `ding` int(10) NOT NULL DEFAULT '0' COMMENT '对顶的操作'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户操作表';

--
-- 转存表中的数据 `userwork`
--

INSERT INTO `userwork` (`work_id`, `userid`, `liuyanid`, `cai`, `ding`) VALUES
(1, 1, 121, 0, 1),
(2, 1, 120, 0, 0),
(3, 2, 121, 0, 1),
(4, 1, 135, 0, 1),
(5, 2, 135, 0, 1),
(6, 1, 134, 0, 1),
(7, 1, 133, 0, 1),
(8, 1, 130, 0, 0),
(9, 1, 127, 0, 0),
(10, 2, 134, 0, 0),
(11, 2, 130, 0, 0),
(12, 2, 133, 0, 0),
(13, 2, 138, 0, 0),
(14, 2, 137, 0, 0),
(15, 1, 141, 1, 0),
(16, 1, 140, 1, 0),
(17, 2, 140, 0, 0),
(18, 2, 127, 0, 1),
(19, 2, 139, 0, 1),
(20, 2, 141, 1, 0),
(21, 3, 140, 1, 0),
(22, 3, 139, 1, 0),
(23, 3, 138, 0, 1),
(24, 3, 137, 0, 0),
(25, 2, 147, 1, 0),
(26, 2, 149, 0, 1),
(27, 2, 162, 0, 1),
(28, 2, 161, 1, 0),
(29, 2, 158, 0, 0),
(30, 2, 163, 0, 0),
(31, 2, 164, 0, 0),
(32, 2, 165, 0, 1),
(33, 2, 142, 0, 1),
(34, 2, 167, 0, 1),
(35, 2, 155, 0, 1),
(36, 1, 167, 0, 1),
(37, 1, 161, 0, 1),
(38, 1, 155, 0, 1),
(39, 1, 147, 1, 0),
(40, 1, 168, 0, 1),
(41, 2, 168, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userwork`
--
ALTER TABLE `userwork`
  ADD PRIMARY KEY (`work_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userwork`
--
ALTER TABLE `userwork`
  MODIFY `work_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '操作ID标识', AUTO_INCREMENT=42;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
