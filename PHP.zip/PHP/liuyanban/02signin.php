<?php
	//1.连接数据库
	include_once "common.php";

	
	
	//2.获取用户名
	$name = $_GET["user"];
	$sql = "SELECT name FROM userinfo WHERE name='{$name}'";
	$result = $mysqli->query($sql);
	if($result->num_rows){
		echo '{"msg":"1"}'; 
		//不可用
	}else{
		echo '{"msg":"0"}';
		 
	}
	//向数据库中追加数据
//		$sql = "INSERT INTO userinfo(name,pass) VALUES('$name','$pass')";
//		$result = $mysqli->query();
//	echo "<script>window.location.href='001login.php';</script>"; 
//			 header("Location: http://localhost/03PHP/liuyanban_test/001login.php");
	if(isset($_POST["username"])){
		$name = $POST["username"];
	}
	if(isset($_POST["password"]){
		$pass = $POST["password"];
	}
	if($name!=null&&$pass!=null){
		//查询
		$sql = "SELECT name FROM userinfo WHERE name='{$name}'";
	    $result = $mysqli->query($sql);
	}
	
	
 	
	
	 

?>