<?php
	include_once "common.php";
	//1.从liuyaninfo表中进行逻辑删除该条数据纪录
	//2.进行数据交互，返回下一页的第一条数据,
	
	//要删除的留言的ID标识
	$ids = $_GET["id"];
	//当前页面数
	$page = $_GET["page"];
	$index = ($page+1)*PAGESIZE;
	//获取下一页的第一个数据？？？
	$sql = "SELECT * FROM liuyaninfo WHERE deleteId=0 ORDER BY liuyan_id DESC LIMIT $index,1";
	$result = $mysqli->query($sql);
	if($result->num_rows){//
		$row = $result->fetch_assoc();
		$arr = $row;
		$timeStyle = date("Y年m月d日 m:i",$row['times']);
		$arr["timeStyle"] = $timeStyle;
		
	}else{//没有下一页，
		$arr["msg"]="当前页的下一页没有数据";
	}
	
	//逻辑删除语句
	$sql = "UPDATE liuyaninfo SET deleteId =1 WHERE liuyan_id = $ids";
	$result = $mysqli->query($sql);
	if($result){
		//看此时页面影噶显示的页数
		 $sql="SELECT count(liuyan_id) FROM liuyaninfo WHERE deleteId=0";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			$row = $result->fetch_assoc();
			$count = $row["count(liuyan_id)"];
			$pages = ceil($count/PAGESIZE);
			$arr["pages"]=$pages;
		 }
	}
	
	echo json_encode($arr);
	
	
	
	
	

?>