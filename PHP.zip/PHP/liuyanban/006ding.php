<?php
//cai--1,ding--0   cai--0,ding--1    cai--0,ding--0  (cai=1,ding=1(X))
 
	 
	
	//1.连接数据库
	include_once "common.php";
	//2.获取关于留言的ID标识
	$liuyanId = $_GET["liuyanID"];
	//3.获取现在登录的用户的ID标识
	session_start();
	$userId = $_SESSION["id"];
	//查看用户操作表中是否有对该留言进行过操作
	$sql = "SELECT * FROM userwork WHERE userid = $userId AND liuyanid = $liuyanId";
	$result = $mysqli->query($sql);
	if($result->num_rows){
		
		//看一下是否对踩进行了操作
		$row = $result->fetch_assoc();
		$workId = $row["work_id"];
		$cai = $row["cai"];
		if($cai == 0){
	//没有进行过踩（cai-0,ding-1/cai-0,ding-0）
			$ding = $row["ding"];
			if($ding == 0){
				$ding = 1;
			}else{
				$ding = 0;
			}
			//更新用户操作表这条纪录
		
			$sql = "UPDATE userwork SET ding = $ding WHERE work_id = $workId";
			$result = $mysqli->query($sql);
			if($result){
				//查询ding的总个数
				$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND ding =1";
				$result = $mysqli->query($sql);
				if($result->num_rows){
					$row = $result->fetch_assoc();
				 	$count_ding = $row["count(work_id)"];
				}
			}
		 }else{
	//进行过踩操作（取消踩，进行顶操作）
			$cai = 0;
			$ding =1;
			//更新用户操作表（）
			$sql = "UPDATE userwork SET ding=1,cai=0 WHERE work_id = $workId";
			$result = $mysqli->query($sql);
			if($result){
				//查看userwork中顶的总数
				$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND ding =1"; 			$result = $mysqli->query($sql);
				if($result->num_rows){
					$row = $result->fetch_assoc();
				 	$count_ding = $row["count(work_id)"];
				}
			}
		 }
		$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND cai = 1";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			$row = $result->fetch_assoc();
			$count_cai = $row["count(work_id)"];
			
		}
		
	}else{
		//往用户操作表中添加纪录（ding-1,cai-0）
		$ding = 1;
		$cai = 0;
		$sql = "INSERT INTO userwork(userid,liuyanid,ding,cai) VALUES($userId,$liuyanId,1,0)";
		$result = $mysqli->query($sql);
		if($result){
			//查看数据表中有关留言的被顶的总数
			 $sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND ding =1";
			 $result = $mysqli->query($sql);
			if($result->num_rows){
				$row = $result->fetch_assoc();
			 	$count_ding = $row["count(work_id)"];
			}
		}
		$sql = "SELECT count(work_id) FROM userwork WHERE liuyanid = $liuyanId AND cai = 1";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			$row = $result->fetch_assoc();
			$count_cai = $row["count(work_id)"];
			
		}
	}
	//更新留言信息表中的数据
	$sql = "UPDATE liuyaninfo SET ding=$count_ding,cai=$count_cai WHERE liuyan_id = $liuyanId";
	$result = $mysqli->query($sql);
	if($result){
		echo '{"count_ding":"'.$count_ding.'","count_cai":"'.$count_cai.'","ding":"'.$ding.'","cai":"'.$cai.'"}';
	}
	
	
	
	
	
	
	
	
	
	
	

?>