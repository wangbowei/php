<?php
	 header("Content-type:text/html;charset=utf-8");
    // 东八区
	date_default_timezone_set('PRC');
	//连接数据库
	 $mysqli =new mysqli("localhost","root","","liuyanban");
	 //判断是否成功连接
	 if($mysqli->connect_errno){
	 	die($mysqli->connect_error);
	 }
	 $mysqli->query("set names utf8");
	 
	 //一页上显示的数据数目(常量)
	 define("PAGESIZE", 5);
	
?>