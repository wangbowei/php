<?php
	if(isset($_COOKIE["name"])){
		$name = $_COOKIE["name"];
	}else{
		$name = "";
	}
	if(isset($_COOKIE["pass"])){
		$pass = $_COOKIE["pass"];
	}else{
		$pass = "";
	}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>登录页面</title>
	</head>
	<body>
		<form action="01login.php" method="post">
			<input type="text" name="name" id="name" value="<?php echo $name;?>" /><br />
			<input type="text" name="password" id="password" value="<?php echo $pass;?>" /><br />
			<input id="mm" type="checkbox" name="mm" checked="checked" />
			<label for="mm">记住我</label><br />
			<input type="submit" value="登录"/>
		</form>
		<a href="02signin.html">立即注册</a>
	</body>
</html>
