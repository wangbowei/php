<?php
	//连接数据库
	include_once "common.php";
	//1.往数据表liuyaninfo中添加一条纪录
	//2.将该记录进行返回（少量的数据交互中的数据）
	//  包括该添加的记录信息，添加成功之后的页数，格式化的时间
	 
	 session_start();
	 $userid = $_SESSION["id"];
	
	//留言内容
	$context = $_GET["context"];
	//留言发布的时间
	//时间戳的形式（以时间进行倒序排，展示方便）
	$times = time();
	//1.将留言界面需要展示的时间样式date
	//2.留言界面写一个函数来进行处理该时间戳（）
	$timeStyle = date("Y年m月d日  H:i",$times);
	//发布留言时多了留言发布人userid
	$sql = "INSERT INTO liuyaninfo(context,times,userid) VALUES('$context','$times','$userid')";
	$result = $mysqli->query($sql);
	if($result){
		//获取插入数据的当前id
		$ids = $mysqli->insert_id;
		//在数据表liuyanban进行查看数据的个数count
		$sql = "SELECT count(liuyan_id) FROM liuyaninfo WHERE deleteId=0";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			$row = $result->fetch_assoc();
			//数据个数
			$count = $row["count(liuyan_id)"];
			$pages = ceil($count/PAGESIZE);
		}
		
		$sql = "SELECT * FROM liuyaninfo WHERE liuyan_id = '$ids'";
		$result = $mysqli->query($sql);
		if($result->num_rows){
			//拿到该数据
			$row = $result->fetch_assoc();
			$row["pages"] = $pages;
			$row["timeStyle"] = $timeStyle;
			echo json_encode($row);
		}
	 }
	
	

?>